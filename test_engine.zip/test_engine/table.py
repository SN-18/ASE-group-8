# Meta table class
class table:
    def __init__(self):
        self.key = ""
        self.value = -1

